const express = require("express");
const crypto = require("crypto");
const TelegramBot = require("node-telegram-bot-api");

const app = express();
const PORT = process.env.PORT || 3000;
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const CHAT_ID = process.env.TELEGRAM_CHAT_ID;

app.use(express.json());
app.use(express.static("public"));

const requests = new Map();

let bot = null;
if (BOT_TOKEN && CHAT_ID) {
  bot = new TelegramBot(BOT_TOKEN, { polling: true });

  bot.on("callback_query", async (query) => {
    const data = query.data || "";
    const [action, id] = data.split(":");
    const request = requests.get(id);

    if (!request) {
      await bot.answerCallbackQuery(query.id, { text: "Request expired or not found." });
      return;
    }

    if (action === "approve") {
      request.status = "approved";
      await bot.answerCallbackQuery(query.id, { text: "Approved" });
      await bot.editMessageText(
        `🔔 Training request ${id}\n\nStatus: ✅ APPROVED`,
        {
          chat_id: query.message.chat.id,
          message_id: query.message.message_id
        }
      );
    } else if (action === "reject") {
      request.status = "rejected";
      await bot.answerCallbackQuery(query.id, { text: "Rejected" });
      await bot.editMessageText(
        `🔔 Training request ${id}\n\nStatus: ❌ REJECTED`,
        {
          chat_id: query.message.chat.id,
          message_id: query.message.message_id
        }
      );
    }
  });
}

app.post("/api/demo-request", async (_req, res) => {
  const id = "DEMO-" + crypto.randomInt(100000, 999999);
  requests.set(id, { status: "pending", createdAt: Date.now() });

  if (bot) {
    await bot.sendMessage(
      CHAT_ID,
      `🔔 Training verification request\n\nRequest ID: ${id}\n\nNo OTP, PIN, password, or other authentication code is transmitted.`,
      {
        reply_markup: {
          inline_keyboard: [
            [
              { text: "✅ Approve", callback_data: `approve:${id}` },
              { text: "❌ Reject", callback_data: `reject:${id}` }
            ]
          ]
        }
      }
    );
  }

  res.json({ id });
});

app.get("/api/demo-request/:id", (req, res) => {
  const request = requests.get(req.params.id);
  if (!request) return res.status(404).json({ error: "Not found" });
  res.json({ status: request.status });
});

app.get("/health", (_req, res) => {
  res.json({ ok: true, telegramConfigured: Boolean(bot) });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Training demo running on port ${PORT}`);
});
